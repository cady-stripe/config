# What is Greater Monokai?

It's a simple adaptation of the excellent [Monokai](http://studiostyl.es/schemes/monokai) color theme to IntelliJ IDEA, favoring "dark" choices, and optimized for Scala and Haskell.

# How to install

In Mac OSX Lion, copy the .xml to:

  ~/Library/Preferences/IdeaIC11/colors/

In Windows, copy the same .xml file to:

  %HOMEPATH%.IntelliJIdea11\config\colors



